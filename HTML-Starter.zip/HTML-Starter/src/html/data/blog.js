module.exports = {
  title: 'Hello world',
  intro: 'intro text blog page here',
  banner: require('./modules/banner1')
}
