import 'slick-carousel/slick/slick'
// // js Custom
import 'modules/FixHeight'

import 'modules/BrowserDetection'
import 'modules/CheckDevice'
import 'modules/ConvertSvg'
import 'modules/LazyLoadImage'

import 'modules/FormAnimation'


import 'modules/UserAgent'
import 'modules/Header'
import 'modules/Menu'
import 'modules/AnimationScrollPage'
import 'modules/ConvertSvg'




// //ADA support ADA
import 'modules/Popup'
import 'modules/DatePickerDialog'
import 'modules/SelectC8'

// //ADA
import 'modules/ModAccordion'
import 'modules/TabList'
import 'modules/ADAMenu'
import 'modules/ModCarouselSlide'
import 'modules/ADA'

console.log('App desktop')
