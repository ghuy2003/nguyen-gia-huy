Document: https://jestjs.io/docs/getting-started


Document other.
https://www.freecodecamp.org/news/how-to-start-unit-testing-javascript/
https://www.browserstack.com/guide/unit-testing-in-javascript
https://jestjs.io/docs/tutorial-jquery
https://buddy.works/tutorials/testing-with-jest-basic-to%C2%AD-do-application
https://torquemag.io/2019/01/testing-jquery-with-jest-in-wordpress-development/
https://jestjs.io/docs/28.x/tutorial-jquery


Create file unitest in folder 'src/assets/javascripts/test'

file name.test.js


Run all test case;
```sh: 
npm run test or npm run test2

Run one test case:
```sh: 
npm test -- 'name file'
