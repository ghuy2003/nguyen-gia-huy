const backgroundSizes = {
  'sm': '768px',
  'sl': '1024px',
  'md': '992px',
  'lg': '1199px',
  'xl': '1400px',
  'auto': 'auto',
  'cover': 'cover',
  'contain': 'contain'
}
module.exports = {
  backgroundSizes
}
