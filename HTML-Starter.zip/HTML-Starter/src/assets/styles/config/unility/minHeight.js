const minHeight = {
  0: '0',
  full: '100%',
  screen: '100vh',
  banner: '456px'
}
module.exports = {
  minHeight
}
