const classNotClear = ['abcd', 'linh-style-color']
module.exports = {
  classNotClear
}
